<?php
    session_start();

//connect to database
$dbcon = mysqli_connect('localhost', 'root', 'root', 'loginhw');if(!$dbcon){
    die('This is why you died: ' . mysqli_connect_error());
}

//SELECT שאילתא
$sql = "SELECT Email,Pass,Phone FROM users
     WHERE Email = '" . $_POST['email'] . "'
     AND Pass = '" . sha1($_POST['pass']) . "'";
     
//ביצוע השאילתא
$result = mysqli_query($dbcon, $sql);

//שאיבת רשומות מהמאגר מידע
$user = mysqli_fetch_assoc($result);

// אם קיימת רשומה תשמור סשן ותחזיר סטטוס תקין
if (isset($user)) {
    $_SESSION['logged'] = $user;
    echo 200;
} else {
    echo 403;
}